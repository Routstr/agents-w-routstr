# LNVPS Skill

Manage LNVPS virtual private servers using Nostr authentication.

## Commands

### Check VM Status & Expiry
```bash
./skills/lnvps/lnvps.sh status
```
Lists all your VMs with their expiry dates and status.

### Get Renewal Invoice
```bash
./skills/lnvps/lnvps.sh renew <vm_id>
```
Gets a Lightning invoice to renew a specific VM.

### List VMs
```bash
./skills/lnvps/lnvps.sh list
```
Simple list of VM IDs and names.

## Requirements

- `nak` - Nostr Army Knife (https://github.com/fiatjaf/nak)
- `jq` - JSON processor
- `curl` - HTTP client

## Configuration

Nostr keys are read from `~/clawd/nostr.config` automatically.

## How It Works

Uses NIP-98 HTTP Auth to authenticate API requests with the configured Nostr keypair. The script signs events with kind 27235 containing the URL and method being accessed.

## API Reference

- Base URL: `https://api.lnvps.net/api/v1`
- Auth: NIP-98 (Nostr event in Authorization header)
